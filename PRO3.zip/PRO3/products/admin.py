from django.contrib import admin
from .models import product,order



class ProductAdmin(admin.ModelAdmin):
	list_display=['category','name', 'price', 'stock','description'] #20190617
	list_editable=['name', 'price', 'stock','description']
	
admin.site.register(product,ProductAdmin)

class OrderAdmin(admin.ModelAdmin):
	list_display=['name', 'price', 'amount','status'] #20190617
	list_editable=['status']
	
admin.site.register(order,OrderAdmin)


