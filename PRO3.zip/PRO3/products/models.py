from django.db import models

class product(models.Model):
	category=models.CharField(max_length=255)
	name=models.CharField(max_length=255)
	price=models.FloatField()
	stock=models.IntegerField()
	description=models.CharField(max_length=255) #20190617
	image=models.CharField(max_length=2083)
	
	
class order(models.Model):
	name=models.CharField(max_length=255)
	price=models.FloatField()
	image=models.CharField(max_length=2083)
	amount=models.FloatField()
	status=models.BooleanField()

	
	

	
