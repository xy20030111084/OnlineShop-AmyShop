from django.http import HttpResponse
from django.shortcuts import render
from .models import product

	
#def product(request):
	#products=product.objects.all()
	#return render(request,'product.html',{'products':products})
	#return render(request,'product.html')	
	
def index(request):
	products=product.objects.all()
    #return HttpResponse('dd')
	return render(request,'index.html',{'products':products})
	

def home(request):
	return render(request,'home.html')
	
	
def order(request):
	#orders=order.objects.all()
	#return render(request,'order.html',{'orders':orders})
	return render(request,'order.html')
	

