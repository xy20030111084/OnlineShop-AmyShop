from django.shortcuts import render

from .forms import ContactForm
def contact(request):
	context=locals()
	return render(request,contactform.html,context)

# Create your views here.
